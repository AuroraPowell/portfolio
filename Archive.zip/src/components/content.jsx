
import EventList from './eventComponents/eventList'

function Content() {
  
    // for each event in list, show title, location, rsvp list and edit availabilty 
    // json object stores information, updated as necessary. 
  
    // main values: yes, no, maybe, plus ones, 
    // (OPTIONAL: conditional settings for posts capping or restricting plus ones)


 
  
    // function handleEdit(){
    //   //send to handleListChange, editing information dependent on what value is changing. 
    // }
  
    // function handleListChange(){
  
    // }
  
    return (
      <>
        <EventList />
      </>
    )
  }
  
  export default Content