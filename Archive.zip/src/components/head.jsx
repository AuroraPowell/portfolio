function Header(){

    return(
        <>
            <h1 className='float-start p-3 text-3xl text-white font-bold rounded-full'>
                Count Me In
            </h1>
        </>
    )
}

export default Header